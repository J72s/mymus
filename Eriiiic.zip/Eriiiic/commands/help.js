const strings = require("../strings.json");

/** 
 * @description Display all available commands
 * @param {Discord.Client} client the client that runs the commands
 * @param {Discord.Message} message the command's message
 * @param {Array<String>} args arguments passed with the command
 */
module.exports.run = async (client, message, args) => {
    try {
        // Get all commands
        const commands = client.commands.map(cmd => cmd.names.list.join(", ")).join("\n");

        // Generate the help message
        const helpMessage = `**Available Commands:**\n${commands}`;

        // Send the help message
        message.channel.send(strings.helpm);
    } catch (error) {
        console.error("Error occurred while displaying help:", error);
        message.channel.send(strings.errorHelp);
    }
};

module.exports.names = {
    list: ["help", "مساعدة"]
};

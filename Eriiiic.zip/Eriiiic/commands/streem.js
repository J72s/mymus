const ytdl = require("ytdl-core-discord");
const strings = require("../strings.json");

/** 
 * @description Stream a video in a voice channel
 * @param {Discord.Client} client the client that runs the commands
 * @param {Discord.Message} message the command's message
 * @param {Array<String>} args arguments passed with the command (should contain the video link)
 */
module.exports.run = async (client, message, args) => {
    try {
        // Check if the user is in a voice channel
        if (!message.member.voice.channel) {
            return message.channel.send(strings.notInVocal);
        }

        // Check if a video link is provided
        const videoLink = args[0];
        if (!videoLink) {
            return message.channel.send(strings.noVideoLink);
        }

        // Join the user's voice channel
        const connection = await message.member.voice.channel.join();

        // Stream the video's audio in the voice channel
        const dispatcher = connection.play(await ytdl(videoLink), { type: "opus" });

        // Handle errors
        dispatcher.on("error", (error) => {
            console.error("Error occurred while streaming video:", error);
            message.channel.send(strings.errorStreaming);
        });

        // Inform the user that the video is being streamed
        message.channel.send(strings.streamingStarted);
    } catch (error) {
        console.error("Error occurred while streaming video:", error);
        message.channel.send(strings.errorStreaming);
    }
};

module.exports.names = {
    list: ["stream", "بث"]
};

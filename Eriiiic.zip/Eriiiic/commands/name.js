const strings = require("../strings.json");
const utils = require("../utils");

/** 
 * @description Change the bot's username
 * @param {Discord.Client} client the client that runs the commands
 * @param {Discord.Message} message the command's message
 * @param {Array<String>} args arguments passed with the command
 */
module.exports.run = async (client, message, args) => {
    // Check if the message is sent in a guild
    if (!message.guild) {
        return message.channel.send(strings.notInGuild);
    }

    // Check if the message author has permission to manage the server
    if (!message.member.permissions.has('ADMINISTRATOR')) {
        return message.channel.send(strings.noPermission);
    }

    try {
        // Prompt the user for the bot's password
        await message.channel.send(strings.passwordPrompt);

        const filter = m => m.author.id === message.author.id;
        const collector = message.channel.createMessageCollector(filter, { max: 1, time: 60000 });

        collector.on('collect', async collected => {
            const password = collected.content.trim();

            // Join the arguments to form the new username
            const newUsername = args.join(" ");

            // Check if the new username is provided
            if (!newUsername || newUsername.length < 2 || newUsername.length > 32) {
                return message.channel.send(strings.invalidUsername);
            }
            
            // Check if the new username is provided
            if (!newUsername) {
                return message.channel.send(strings.noUsername);
            }

            // Set the bot's username to the provided one using the password
            await client.user.setUsername(newUsername, password);

            // Send a confirmation message
            message.channel.send(strings.usernameChanged);
        });

        collector.on('end', collected => {
            if (collected.size === 0) {
                message.channel.send(strings.passwordTimeout);
            }
        });
    } catch (error) {
        console.error("Error occurred while changing username:", error);
        message.channel.send(strings.errorChangingUsername);
    }
};


module.exports.names = {
    list: ["changename", "usern", "تغييرالاسم"]
};

const strings = require("../strings.json");
const utils = require("../utils");

/** 
 * @description Skip the current song
 * @param {Discord.Client} client the client that runs the commands
 * @param {Discord.Message} message the command's message
 * @param {Array<String>}args useless here  
 */
module.exports.run = async (client, message, args) => {
    try {
        let voiceChannel = message.member.voice.channel; 

        if (!voiceChannel) {
            return message.channel.send(strings.notInVocal);
        }

        const serverQueue = queue.get("queue");
        if (!serverQueue || !serverQueue.songs) {
            return message.channel.send(strings.nothingPlaying);
        }

        utils.log(`Skipped music: ${serverQueue.songs[0].title}`);

        // Check if there's an active connection
        if (serverQueue.connection) {
            serverQueue.skipped = true;
            serverQueue.connection._state.subscription.player.stop();
        } else {
            return message.channel.send(strings.errorStop);
        }

        return message.channel.send(strings.musicSkipped);
    } catch (error) {
        console.error("Error occurred while skipping music:", error);
        message.channel.send(strings.errorSkipping);
    }
};

module.exports.names = {
    list: ["skip", "s", "سكب", "س"]
};

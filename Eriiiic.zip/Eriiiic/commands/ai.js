const axios = require("axios");
const { prefix, openaiApiKey } = require("./config.json");

// Function to send message to ChatGPT via OpenAI API
async function sendMessageToChatGPT(message) {
    try {
        const response = await axios.post(
            "https://api.openai.com/v1/completions",
            {
                model: "text-davinci-002", // or any other Arabic language model
                prompt: message,
                max_tokens: 150, // adjust as needed
                temperature: 0.7, // adjust as needed
                stop: ["\n"] // stop generation at newlines
            },
            {
                headers: {
                    "Content-Type": "application/json",
                    "Authorization": `Bearer ${openaiApiKey}`
                }
            }
        );
        return response.data.choices[0].text.trim();
    } catch (error) {
        console.error("Error sending message to ChatGPT:", error);
        return "Sorry, I couldn't process your message.";
    }
}

// Command execution function
module.exports.run = async (client, message, args) => {
    if (args[0] === "ai") {
        // Extract user's message to send to ChatGPT
        const userMessage = args.slice(1).join(" ");

        // Send user's message to ChatGPT and wait for response
        const aiResponse = await sendMessageToChatGPT(userMessage);

        // Send ChatGPT's response back to the Discord channel
        message.channel.send(aiResponse);
    } else {
        // Handle other commands (if any)
    }
};

// Command names
module.exports.names = {
    list: ["ai"] // Command names
};

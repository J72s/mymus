const strings = require("../strings.json");
const utils = require("../utils");

/** 
 * @description Change the bot's display name in a guild
 * @param {Discord.Client} client the client that runs the commands
 * @param {Discord.Message} message the command's message
 * @param {Array<String>} args arguments passed with the command
 */
module.exports.run = async (client, message, args) => {
    // Check if the message is sent in a guild
    if (!message.guild) {
        return message.channel.send(strings.notInGuild2);
    }

    // Check if the message author has permission to manage nicknames
    if (!message.member.permissions.has('MANAGE_NICKNAMES')) {
        return message.channel.send(strings.noPermission2);
    }

    try {
        // Join the arguments to form the new display name
        const newNickname = args.join(" ");

        // Check if the new display name is provided
        if (!newNickname) {
            return message.channel.send(strings.noNickname);
        }

        // Set the bot's display name to the provided one
        await message.guild.me.setNickname(newNickname);

        // Send a confirmation message
        message.channel.send(strings.nicknameChanged);
    } catch (error) {
        console.error("Error occurred while changing nickname:", error);
        message.channel.send(strings.errorChangingNickname);
    }
};

module.exports.names = {
    list: ["changenickname", "name", "تغييرالاسم"]
};

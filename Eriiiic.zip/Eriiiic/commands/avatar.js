const strings = require("../strings.json");
const utils = require("../utils");

/** 
 * @description Change the bot's avatar
 * @param {Discord.Client} client the client that runs the commands
 * @param {Discord.Message} message the command's message
 * @param {Array<String>} args arguments passed with the command
 */
module.exports.run = async (client, message, args) => {
    // Check if the message is sent in a guild
    if (!message.guild) {
        return message.channel.send(strings.notInGuild);
    }

    // Check if the message author has permission to manage the server
    if (!message.member.permissions.has('ADMINISTRATOR')) {
        return message.channel.send(strings.noPermission);
    }

    try {
        // Fetch the attachment (avatar) sent with the command
        const attachment = message.attachments.first();
        if (!attachment) {
            return message.channel.send(strings.noAttachment);
        }

        // Set the bot's avatar to the attached image
        await client.user.setAvatar(attachment.url);

        // Send a confirmation message
        message.channel.send(strings.avatarChanged);
    } catch (error) {
        console.error("Error occurred while changing avatar:", error);
        message.channel.send(strings.errorChangingAvatar);
    }
};

module.exports.names = {
    list: ["ava", "avatar", "تغييرالصورة"]
};

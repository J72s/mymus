// Mock chat AI service

// Function to simulate sending a message to the chat AI and getting a response
async function sendMessage(message) {
    // For demonstration purposes, just echo back the user's message
    return `AI Response: ${message}`;
}

// Export the function to be used in other files
module.exports = {
    sendMessage
};
